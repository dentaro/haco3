// #include <Arduino.h>
// #include <FS.h>
// #include "SPIFFS.h"
// #include "string.h"

// #ifndef TUNES_H
// #define TUNES_H
#define SPEAKER_PIN 25
// #define BUZZER_CHANEL 0 

// class Tunes
// {
//   public:
//     static volatile SemaphoreHandle_t timerSemaphore;
//     static portMUX_TYPE timerMux;

//     static volatile uint32_t isrCounter;
//     static volatile uint32_t lastIsrAt;
//     static volatile uint16_t osc1;
//     static volatile uint16_t osc2;
//     static volatile uint16_t osc3;
//     static volatile uint16_t d[3];
//     static  unsigned int tones[38];
//     static int SineValues[256];
//     static int SquareValues[256];
//     static hw_timer_t* timer;
    

//     void init();
//     void static IRAM_ATTR onTimer();
//     void run();
//     void pause();
//     void resume();
//     // void static task1(void *pvParameters);

// };
// #endif


