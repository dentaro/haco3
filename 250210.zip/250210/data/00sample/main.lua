bgcNo = 13
size = 15
x=64
y=60

function setup()
  debug(0)--デバグ表示
  -- music(2,64,60,0,3)
  fillrect(20,20,80,80,3)
  drawrect(20,20,80,80,7)

  color(8)
  fillcircle(20,20,40)

  
  oval(40,40, 20,30, 9)
end

function _init()--1回だけ
    setup()
end

function _update()--ループします
  if tpf() == true then
    x = tp(0)
    y = tp(1)
  end
end

function _draw()--ループします
  --cls(bgcNo)
  --ovalfill(40,40, 30,30, 9,7)
  --fillrect(x,y,size,size,8)
  --spr8(1,x,y)
  --print("hello world", x, y)
end