-- 迷路と敵を加えたパックマン風ゲーム (Lua)

size = 20  -- マスのサイズ (160x120に収める)
width, height = 8, 6  -- 8x6 の盤面
player_x, player_y = 2, 2  -- プレイヤーの初期位置
enemy_x, enemy_y = 6, 4  -- 敵の初期位置
board = {  -- 迷路のレイアウト (1: 壁, 0: 通路, 2: アイテム)
    {1,1,1,1,1,1,1,1},
    {1,0,0,0,1,0,2,1},
    {1,0,1,0,1,0,0,1},
    {1,0,1,0,0,0,1,1},
    {1,2,0,1,1,0,2,1},
    {1,1,1,1,1,1,1,1}
}

-- プレイヤーの移動処理
function movePlayer(dx, dy)
    local new_x, new_y = player_x + dx, player_y + dy
    if board[new_y][new_x] ~= 1 then  -- 壁でなければ移動
        player_x, player_y = new_x, new_y
        if board[player_y][player_x] == 2 then
            board[player_y][player_x] = 0  -- アイテムを取得
        end
    end
end

-- 敵の移動処理 (ランダム移動)
function moveEnemy()
    local dx, dy = math.random(-1, 1), math.random(-1, 1)
    local new_x, new_y = enemy_x + dx, enemy_y + dy
    if new_x >= 2 and new_x <= width-1 and new_y >= 2 and new_y <= height-1 and board[new_y][new_x] ~= 1 then
        enemy_x, enemy_y = new_x, new_y
    end
end

-- ボタン入力処理
function _update()
    if btn(1) >= 1 then movePlayer(-1, 0) end  -- 左移動
    if btn(2) >= 1 then movePlayer(1, 0) end   -- 右移動
    if btn(3) >= 1 then movePlayer(0, -1) end  -- 上移動
    if btn(4) >= 1 then movePlayer(0, 1) end   -- 下移動
    moveEnemy()
end

-- 盤面の描画
function _draw()
    cls(15)  -- 背景色
    for y = 1, height do
        for x = 1, width do
            local px, py = (x - 1) * size, (y - 1) * size
            if board[y][x] == 1 then
                fillrect(px, py, size, size, 7)  -- 壁
            elseif board[y][x] == 2 then
                fillrect(px + 5, py + 5, size - 10, size - 10, 10)  -- アイテム
            end
        end
    end
    -- プレイヤーの描画
    fillrect((player_x - 1) * size + 5, (player_y - 1) * size + 5, size - 10, size - 10, 3)
    -- 敵の描画
    fillrect((enemy_x - 1) * size + 5, (enemy_y - 1) * size + 5, size - 10, size - 10, 8)
end

-- 初期化
function _init()
    math.randomseed(os.time())
end
