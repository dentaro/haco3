camera = creobj1(0)  -- カメラの作成
light = creobj1(1)   -- 光源の作成
obj1 = creobj1(2)    -- オブジェクト1の作成
colangle = 0        -- 色の角度（回転）

-- 正20面体生成
function createIcosahedron()
  local phi = (1 + math.sqrt(5)) / 2

  -- 正20面体の頂点
  local vertices = {
    {-1, phi, 0}, {1, phi, 0}, {-1, -phi, 0}, {1, -phi, 0},
    {0, -1, phi}, {0, 1, phi}, {0, -1, -phi}, {0, 1, -phi},
    {phi, 0, -1}, {phi, 0, 1}, {-phi, 0, -1}, {-phi, 0, 1}
  }

  -- 正20面体の面（頂点インデックス）
  local faces = {
    {1, 12, 6}, {1, 6, 2}, {1, 2, 8}, {1, 8, 11}, {1, 11, 12},
    {2, 6, 10}, {6, 12, 5}, {12, 11, 3}, {11, 8, 7}, {8, 2, 9},
    {4, 10, 5}, {4, 5, 3}, {4, 3, 7}, {4, 7, 9}, {4, 9, 10},
    {5, 10, 6}, {3, 5, 12}, {7, 3, 11}, {9, 7, 8}, {10, 9, 2}
  }

  -- 頂点をポリゴンとして返す
  local poly_vertices = {}
  for _, face in ipairs(faces) do
    for _, index in ipairs(face) do
      table.insert(poly_vertices, vertices[index])
    end
  end
  return poly_vertices
end

-- 正20面体の頂点を取得
local poly_vertices = createIcosahedron()

-- 初期設定
function setup()
  -- 初期設定があればここに記述
end

function _init()  -- 1回だけ実行
  setup()
end

function _update()  -- 更新処理
  if camera.angle > 360 then 
    camera.angle = 0
  end

  -- カメラの移動と回転
  if btnp(1) then
    camera.x = camera.x + 1  -- 左に移動
  elseif btnp(2) then
    camera.x = camera.x - 1  -- 右に移動
  end

  if btnp(3) then
    camera.y = camera.y + 1  -- 上に移動
  elseif btnp(4) then
    camera.y = camera.y - 1  -- 下に移動
  end

  if btnp(6) then
    camera.zoom = camera.zoom - 0.05  -- ズームイン
  elseif btnp(8) then
    camera.zoom = camera.zoom + 0.05  -- ズームアウト
  end

  colangle = colangle + 1
  if colangle > 360 then 
    colangle = colangle - 360
  end

  obj1.angle = obj1.angle + 1
  if obj1.angle > 360 then 
    obj1.angle = obj1.angle - 360
  end
end 

function _draw()  -- 描画処理
  cls(1)  -- 背景をクリア
  
  -- オブジェクトの位置と回転を更新
  trans(obj1.x, obj1.y, obj1.z, obj1.angle, obj1.size, 2, colangle)
  
  -- カメラの設定
  cam(camera.x, camera.y, camera.z, camera.angle, camera.zoom)
  
  -- 正20面体を描画
  rendr1(poly_vertices)  -- 頂点データを使って描画
end
