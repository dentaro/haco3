-- p, s はオブジェクトのサイズや位置のスケール
local p = 0.5
local s = 0.2

-- 3Dオブジェクトの作成（位置、色などの設定）
creobj2(1, -p, -p * 2, 0.0, 90, 127, 192, s) -- CMY
creobj2(1, 0.0, -p * 2, 0.0, 210, 127, 128, s)
creobj2(1, p, -p * 2, 0.0, 330, 127, 96, s)

creobj2(1, -p, -p, 0.0, 60, 127, 128, s) -- CMY
creobj2(1, 0.0, -p, 0.0, 180, 127, 128, s)
creobj2(1, p, -p, 0.0, 300, 127, 128, s)

creobj2(1, -p, 0.0, 0.0, 0, 127, 128, s) -- RGB
creobj2(1, 0.0, 0.0, 0.0, 120, 127, 128, s)
creobj2(1, p, 0.0, 0.0, 240, 127, 128, s)

-- カメラの設定
local camera = {
  x = 0,
  y = 0,
  z = 1.0,
  anglex = 0,
  angley = 0,
  anglez = 0,
  zoom = 1.0
}

-- 光源の設定
local light = {
  x = 1,
  y = 3,
  z = 10
}

-- カメラの更新処理
function _update()
  if btnp(1) then
    camera.x = camera.x - 0.05  -- 左に移動
  end
  if btnp(2) then
    camera.x = camera.x + 0.05  -- 右に移動
  end
  if btnp(3) then
    camera.y = camera.y + 0.05  -- 上に移動
  end
  if btnp(4) then
    camera.y = camera.y - 0.05  -- 下に移動
  end

  -- ズーム調整（ズームアウトとズームイン）
  if btnp(5) then
    camera.zoom = camera.zoom - 0.05
  end
  if btnp(6) then
    camera.zoom = camera.zoom + 0.05
  end

  -- ズーム制限
  if camera.zoom < 0.1 then
    camera.zoom = 0.1
  end
end

-- 描画処理
function _draw()
  cls(8)  -- 背景をクリア
  rendr2(camera.x, camera.y, camera.z, camera.anglex, camera.angley, 1, camera.zoom)  -- 3D描画
end
