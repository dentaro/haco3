-- タッチ式マインスイーパ (Lua)

size = 20  -- マスのサイズ (160x120に収める)
width, height = 8, 6  -- 8x6 の盤面
mine_count = 10  -- 地雷の数
board = {}  -- 盤面情報 (0: 空, -1: 地雷, 他: 隣接地雷数)
revealed = {}  -- 開示状態

touch_x, touch_y = -1, -1

-- 盤面の初期化
function initBoard()
    for x = 1, width do
        board[x] = {}
        revealed[x] = {}
        for y = 1, height do
            board[x][y] = 0
            revealed[x][y] = false
        end
    end
    -- 地雷を配置
    local placed = 0
    while placed < mine_count do
        local x, y = math.random(1, width), math.random(1, height)
        if board[x][y] == 0 then
            board[x][y] = -1
            placed = placed + 1
        end
    end
    -- 隣接する地雷の数を計算
    local directions = {{-1,0}, {1,0}, {0,-1}, {0,1}, {-1,-1}, {-1,1}, {1,-1}, {1,1}}
    for x = 1, width do
        for y = 1, height do
            if board[x][y] == 0 then
                local count = 0
                for _, dir in ipairs(directions) do
                    local nx, ny = x + dir[1], y + dir[2]
                    if nx >= 1 and nx <= width and ny >= 1 and ny <= height and board[nx][ny] == -1 then
                        count = count + 1
                    end
                end
                board[x][y] = count
            end
        end
    end
end

-- クリック処理
function reveal(x, y)
    if x < 1 or x > width or y < 1 or y > height or revealed[x][y] then return end
    revealed[x][y] = true
    if board[x][y] == 0 then
        local directions = {{-1,0}, {1,0}, {0,-1}, {0,1}, {-1,-1}, {-1,1}, {1,-1}, {1,1}}
        for _, dir in ipairs(directions) do
            reveal(x + dir[1], y + dir[2])
        end
    end
end

-- タッチ入力処理
function _update()
    if tpf() then
        touch_x, touch_y = math.floor(tp(0) / size) + 1, math.floor(tp(1) / size) + 1
        if touch_x >= 1 and touch_x <= width and touch_y >= 1 and touch_y <= height then
            reveal(touch_x, touch_y)
        end
    end
end

-- 盤面の描画
function _draw()
    cls(15)  -- 背景色
    for x = 1, width do
        for y = 1, height do
            local px, py = (x - 1) * size, (y - 1) * size
            drawrect(px, py, size, size, 7)  -- マス描画
            if revealed[x][y] then
                if board[x][y] == -1 then
                    fillrect(px + 5, py + 5, size - 10, size - 10, 8)  -- 地雷
                elseif board[x][y] > 0 then
                    text(tostring(board[x][y]), px + 6, py + 6, 0)  -- 数字
                end
            end
        end
    end
end

-- 初期化
function _init()
    initBoard()
end
