-- タッチ式オセロ (Lua)

size = 20  -- マスのサイズ (160x120に収める)
board = {}  -- 8x6のオセロ盤面
turn = 1  -- 1: 黒, -1: 白

-- 盤面の初期化
function initBoard()
    for x = 1, 8 do
        board[x] = {}
        for y = 1, 6 do
            board[x][y] = 0
        end
    end
    board[4][3], board[5][4] = -1, -1  -- 白
    board[4][4], board[5][3] = 1, 1  -- 黒
end

-- 駒を置けるか判定 (x, y に現在の turn の駒を置けるか)
function canPlace(x, y, player)
    if board[x][y] ~= 0 then return false end
    local directions = {{-1,0}, {1,0}, {0,-1}, {0,1}, {-1,-1}, {-1,1}, {1,-1}, {1,1}}
    for _, dir in ipairs(directions) do
        local dx, dy = dir[1], dir[2]
        local nx, ny = x + dx, y + dy
        local found = false
        while nx >= 1 and nx <= 8 and ny >= 1 and ny <= 6 do
            if board[nx][ny] == -player then
                found = true
            elseif board[nx][ny] == player then
                if found then return true end
                break
            else
                break
            end
            nx = nx + dx
            ny = ny + dy
        end
    end
    return false
end

-- 駒を置く (x, y に player の駒を置く)
function placePiece(x, y, player)
    if not canPlace(x, y, player) then return false end
    board[x][y] = player
    local directions = {{-1,0}, {1,0}, {0,-1}, {0,1}, {-1,-1}, {-1,1}, {1,-1}, {1,1}}
    for _, dir in ipairs(directions) do
        local dx, dy = dir[1], dir[2]
        local nx, ny = x + dx, y + dy
        local flip = {}
        while nx >= 1 and nx <= 8 and ny >= 1 and ny <= 6 do
            if board[nx][ny] == -player then
                table.insert(flip, {nx, ny})
            elseif board[nx][ny] == player then
                for _, pos in ipairs(flip) do
                    board[pos[1]][pos[2]] = player
                end
                break
            else
                break
            end
            nx = nx + dx
            ny = ny + dy
        end
    end
    return true
end

-- タッチ入力処理
function _update()
    if tpf() then
        local tx, ty = tp(0), tp(1)
        local x, y = math.floor(tx / size) + 1, math.floor(ty / size) + 1
        if x >= 1 and x <= 8 and y >= 1 and y <= 6 then
            if placePiece(x, y, turn) then
                turn = -turn  -- プレイヤー交代
            end
        end
    end
end

-- 盤面の描画
function _draw()
    cls(15)  -- 背景色
    for x = 1, 8 do
        for y = 1, 6 do
            local px, py = (x - 1) * size, (y - 1) * size
            drawrect(px, py, size, size, 7)  -- マス描画
            if board[x][y] == 1 then
                fillrect(px + 5, py + 5, size - 10, size - 10, 0)  -- 黒石
            elseif board[x][y] == -1 then
                fillrect(px + 5, py + 5, size - 10, size - 10, 14)  -- 白石
            end
        end
    end
end

-- 初期化
function _init()
    initBoard()
end
