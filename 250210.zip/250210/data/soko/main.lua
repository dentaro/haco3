-- 倉庫番風ゲーム (Lua)

size = 20  -- マスのサイズ (160x120に収める)
width, height = 8, 6  -- 8x6 の盤面
player_x, player_y = 2, 4  -- プレイヤーの初期位置
board = {  -- 迷路のレイアウト (1: 壁, 0: 通路, 2: 荷物, 3: 目的地)
    {1,1,1,1,1,1,1,1},
    {1,0,0,1,1,0,0,1},  -- 3を0に変更
    {1,0,2,0,1,0,0,1},
    {1,0,1,0,2,0,1,1},
    {1,3,0,0,1,0,3,1},  -- 3を1つ減らす
    {1,1,1,1,1,1,1,1}
}

-- プレイヤーの移動処理
function movePlayer(dx, dy)
    local new_x, new_y = player_x + dx, player_y + dy
    if board[new_y][new_x] == 1 then return end  -- 壁なら移動しない
    
    -- 荷物を押す処理
    if board[new_y][new_x] == 2 then
        local box_x, box_y = new_x + dx, new_y + dy
        if board[box_y][box_x] == 0 or board[box_y][box_x] == 3 then
            board[box_y][box_x] = 2  -- 荷物を移動
            board[new_y][new_x] = 0
        else
            return  -- 荷物が動かせない場合は移動しない
        end
    end
    
    player_x, player_y = new_x, new_y
end

-- ボタン入力処理
function _update()
    if btn(1) >= 1 then movePlayer(-1, 0) end  -- 左移動
    if btn(2) >= 1 then movePlayer(1, 0) end   -- 右移動
    if btn(3) >= 1 then movePlayer(0, -1) end  -- 上移動
    if btn(4) >= 1 then movePlayer(0, 1) end   -- 下移動
end

-- 盤面の描画
function _draw()
    cls(15)  -- 背景色
    for y = 1, height do
        for x = 1, width do
            local px, py = (x - 1) * size, (y - 1) * size
            if board[y][x] == 1 then
                fillrect(px, py, size, size, 7)  -- 壁
            elseif board[y][x] == 2 then
                fillrect(px + 5, py + 5, size - 10, size - 10, 9)  -- 荷物
            elseif board[y][x] == 3 then
                fillrect(px + 5, py + 5, size - 10, size - 10, 10)  -- 目的地
            end
        end
    end
    -- プレイヤーの描画
    fillrect((player_x - 1) * size + 5, (player_y - 1) * size + 5, size - 10, size - 10, 3)
end

-- 初期化
function _init()
end
